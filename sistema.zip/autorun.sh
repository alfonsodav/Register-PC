#!/bin/bash

python3 /home/alfonsom/PycharmProjects/eloisa/manage.py runserver
