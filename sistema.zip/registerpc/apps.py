from django.apps import AppConfig



class RegisterpcConfig(AppConfig):
    name = 'registerpc'
